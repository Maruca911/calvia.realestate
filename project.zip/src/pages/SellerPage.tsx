import { Building2, TrendingUp, Clock, Eye, ArrowRight } from 'lucide-react';
import SellerSection from '../components/SellerSection';
import ProcessSteps from '../components/ProcessSteps';
import FAQSection from '../components/FAQSection';
import RecommendedReading from '../components/RecommendedReading';
import Footer from '../components/Footer';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { usePageMeta } from '../hooks/usePageMeta';
import { sellerFaqs } from '../data/sellerFaqs';
import { blogPosts } from '../data/blogPosts';
import type { Route } from '../hooks/useRouter';

interface SellerPageProps {
  onComplete: (refCode: string) => void;
  navigate: (to: Route) => void;
}

const SELLER_BLOG_SLUGS = [
  'short-term-renting-calvia',
  'new-developments-calvia-mallorca',
  'best-agencies-notaries-calvia',
];

const BENEFITS = [
  {
    icon: TrendingUp,
    title: 'Maximise Your Returns',
    description: 'We connect you with agencies that specialise in your property type and price bracket \u2014 ensuring expert pricing, marketing, and negotiation from day one.',
  },
  {
    icon: Clock,
    title: 'Speed Without Compromise',
    description: 'No weeks of interviewing agents. Describe your property once, and we introduce you to the right one who can start immediately.',
  },
  {
    icon: Eye,
    title: 'Discretion Guaranteed',
    description: 'Need a quiet sale or discreet rental? Our network includes agencies experienced in off-market and confidential transactions. Your privacy is our priority.',
  },
];

export default function SellerPage({ onComplete, navigate }: SellerPageProps) {
  const { ref: heroRef, isVisible: heroVisible } = useScrollReveal(0.1);
  const { ref: benefitsRef, isVisible: benefitsVisible } = useScrollReveal(0.1);

  usePageMeta({
    title: 'Sell or Rent Property in Calvia, Mallorca | Home Owner Matching | Calvia Real Estate',
    description: 'Selling or renting property in Calvia, Mallorca? Get matched to the best local estate agencies for your property type and price range. Villas, apartments, fincas -- expert agents who know the market.',
    keywords: 'sell property Calvia, rent property Calvia, Mallorca property owners, sell villa Mallorca, estate agents Calvia, rent apartment Santa Ponsa, Bendinat property, real estate Calvia',
  });

  const recommendedPosts = blogPosts.filter((p) => SELLER_BLOG_SLUGS.includes(p.slug));

  return (
    <>
      <section className="pt-28 pb-16 md:pt-36 md:pb-20 bg-white">
        <div
          ref={heroRef}
          className={`max-w-4xl mx-auto px-6 text-center transition-all duration-700 ${
            heroVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-dark-blue/10 mb-6">
            <Building2 className="w-8 h-8 text-dark-blue" />
          </div>
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-black mb-5 leading-tight">
            Sell or Rent Your Calvi&agrave; Property with Confidence
          </h1>
          <p className="text-lg md:text-xl text-grey-dark max-w-2xl mx-auto leading-relaxed mb-3">
            Describe your property once. Our team identifies the best agency to handle your sale or rental
            &mdash; then connects you directly via your preferred channel.
          </p>
          <p className="text-base text-grey max-w-xl mx-auto">
            WhatsApp, email, or phone call &mdash; you choose how to connect with your matched agent.
          </p>
          <div className="mt-8">
            <button
              onClick={() => document.getElementById('seller-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="inline-flex items-center gap-2 px-8 py-3.5 bg-dark-blue text-white font-semibold rounded-lg text-lg transition-all duration-300 hover:bg-dark-blue-light hover:shadow-[0_0_30px_rgba(0,31,63,0.3)] hover:-translate-y-0.5"
            >
              List Your Property
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-beige">
        <div className="max-w-5xl mx-auto px-6">
          <ProcessSteps variant="seller" />
        </div>
      </section>

      <section className="py-16 md:py-20 bg-white">
        <div
          ref={benefitsRef}
          className={`max-w-5xl mx-auto px-6 transition-all duration-700 ${
            benefitsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="text-center mb-12">
            <h3 className="font-heading text-2xl md:text-3xl font-bold text-black mb-3">
              Why List Through Calvia Real Estate?
            </h3>
            <p className="text-grey max-w-lg mx-auto">
              We are not an agency. We are the shortcut to the right one for your property.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {BENEFITS.map((benefit) => (
              <div
                key={benefit.title}
                className="bg-beige/30 rounded-xl p-7 border border-beige-dark/40 hover:shadow-lg hover:shadow-black/5 hover:border-dark-blue/20 transition-all duration-300"
              >
                <benefit.icon className="w-7 h-7 text-dark-blue mb-4" />
                <h4 className="font-bold text-black text-lg mb-2">{benefit.title}</h4>
                <p className="text-grey text-[15px] leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="seller-form" className="py-16 md:py-24 bg-beige">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-10">
            <h3 className="font-heading text-2xl md:text-3xl font-bold text-black mb-3">
              Describe Your Property
            </h3>
            <p className="text-grey max-w-lg mx-auto">
              Takes under 2 minutes. The more detail you provide, the better your agency match.
            </p>
          </div>
          <SellerSection onComplete={onComplete} />
        </div>
      </section>

      <FAQSection
        title="Frequently Asked Questions for Home Owners"
        subtitle="Everything you need to know about selling or renting property in Calvia, Mallorca."
        faqs={sellerFaqs}
        schemaId="seller"
      />

      <RecommendedReading posts={recommendedPosts} navigate={navigate} />

      <Footer navigate={navigate} />
    </>
  );
}
